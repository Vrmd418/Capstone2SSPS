﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentApplications
{
    class Ranking
    {

        private string applicationID;
        private int rank;
        private int adminID = 0;
        private int committeeID = 0;

    }
}
